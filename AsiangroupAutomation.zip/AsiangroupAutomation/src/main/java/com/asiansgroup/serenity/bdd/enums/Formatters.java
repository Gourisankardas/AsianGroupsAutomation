package com.asiansgroup.serenity.bdd.enums;

public enum Formatters {
    PHONENUMBER("(\\d{3})(\\d{3})(\\d+)"), REPLACEMENTS("");

    private final String pattern;

    Formatters(String pattern) {
        this.pattern = pattern;
    }

    public String getPattern() {
        return pattern;
    }
}

package com.asiansgroup.serenity.bdd.enums;

public enum EnvironmentType {
    SERENITY(1), SYSTEM(2);

    private final int value;

    EnvironmentType(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public static EnvironmentType getValue(int value) {
        for (EnvironmentType type : values()) {
            if (type.getValue() == value) {
                return type;
            }
        }
        return null;
    }
}

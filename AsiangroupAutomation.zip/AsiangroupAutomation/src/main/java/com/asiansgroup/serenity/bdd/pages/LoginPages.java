package com.asiansgroup.serenity.bdd.pages;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.pages.PageObject;

public class LoginPages extends PageObject {
    @FindBy(xpath = "//input[@id='username']")
    public WebElementFacade username;

    @FindBy(xpath = "//input[@id='password']")
    public WebElementFacade password;

    @FindBy(xpath = "//input[@id='kc-login']")
    public WebElementFacade login;

    @FindBy(xpath = "//span[@id='input-error']")
    public WebElementFacade errorMessage;

    @FindBy(xpath = "//img[@alt='Vue logo']")
    public WebElementFacade asianLogo;

}

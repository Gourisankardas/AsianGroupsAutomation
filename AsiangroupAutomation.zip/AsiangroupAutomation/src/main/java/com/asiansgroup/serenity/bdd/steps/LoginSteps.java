package com.asiansgroup.serenity.bdd.steps;

import com.asiansgroup.serenity.bdd.pages.LoginPages;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class LoginSteps extends ScenarioSteps {

    @Steps
    LoginPages loginPages;
    WebDriver driver;

    public void openURL() {
        System.setProperty("webdriver.gecko.driver","src/webdriver/geckodriver");
        driver= new FirefoxDriver();
        driver.get("https://console.uat.asians.group/#/domain/list");
        driver.manage().window().maximize();
    }


    public void userLogin1(String id1, String password1) {
        loginPages.username.sendKeys(id1);
        loginPages.password.sendKeys(password1);
    }

    public void verifyErrorMessageforFirstNegativeScenario(String errorMessage) {
        loginPages.login.click();
        String actualErrorMessage=loginPages.errorMessage.getText();
        if(actualErrorMessage.equalsIgnoreCase(errorMessage)){
            System.out.println("Scenario 1 is tested successfully");
        }
    }

    public void userLogin2(String id2, String password2) {
        loginPages.username.sendKeys(id2);
        loginPages.password.sendKeys(password2);
    }

    public void verifyErrorMessageforSecondNegativeScenario(String errorMessage) {
        loginPages.login.click();
        String actualErrorMessage=loginPages.errorMessage.getText();
        if(actualErrorMessage.equalsIgnoreCase(errorMessage)){
            System.out.println("Scenario 2 is tested successfully");
        }

    }

    public void userLogin3(String id3, String password3) {
        loginPages.username.sendKeys(id3);
        loginPages.password.sendKeys(password3);
    }

    public void verifyErrorMessageforThirdNegativeScenario(String errorMessage) {
        loginPages.login.click();
        String actualErrorMessage=loginPages.errorMessage.getText();
        if(actualErrorMessage.equalsIgnoreCase(errorMessage)){
            System.out.println("Scenario 3 is tested successfully");
        }


    }

    public void userLogin(String id, String password) {
        loginPages.login.sendKeys(id);
        loginPages.password.sendKeys(password);

    }

    public void verifyLogin() {
        loginPages.login.click();
        if(loginPages.asianLogo.isDisplayed()){
            System.out.println("User logged in successfully");
        }

    }
}

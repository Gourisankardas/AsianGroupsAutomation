package com.asiansgroup.serenity.bdd.enums;

public enum PARAMETER {
    FORM, QUERY, NONE, PATH
}

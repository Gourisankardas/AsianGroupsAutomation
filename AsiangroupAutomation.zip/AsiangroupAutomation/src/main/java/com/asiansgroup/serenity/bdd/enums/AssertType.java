package com.asiansgroup.serenity.bdd.enums;

public enum AssertType {

    EQUALS, CONTAINS, NOTEQUALS, EQUALSIGNORECASE, MATCHESREGEX, LISTARRAYEQUALS, SIZE
}

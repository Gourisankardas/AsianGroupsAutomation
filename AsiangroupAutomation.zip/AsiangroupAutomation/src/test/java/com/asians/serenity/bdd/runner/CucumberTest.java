package com.asians.serenity.bdd.runner;

import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.CucumberSerenityRunner;
import org.junit.runner.RunWith;

@RunWith(CucumberSerenityRunner.class)
@CucumberOptions(
       features = "src/test/resources/feature.asiansgroup",
        glue = {"com/asians/serenity/bdd/stepDefinitions"},
        tags = "@AsianGroup",
        plugin = {
                "pretty",
                "json:build/cucumber-report/cucumber.json",
                "junit:build/cucumber-report/cucumber.xml",
                "html:build/cucumber-report/cucumber.html"}
)
public class CucumberTest {

}
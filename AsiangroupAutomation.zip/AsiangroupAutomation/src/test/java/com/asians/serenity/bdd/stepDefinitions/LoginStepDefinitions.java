package com.asians.serenity.bdd.stepDefinitions;

import com.asiansgroup.serenity.bdd.steps.LoginSteps;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import net.thucydides.core.annotations.Steps;


public class LoginStepDefinitions {
    @Steps
    LoginSteps loginSteps;
    @Given("User is on asian group login page")
    public void userIsOnAsianGroupLoginPage() {
        loginSteps.openURL();

    }

    @Then("Enter Valid {string} and Invalid {string}")
    public void enterValidAndInvalid(String id1, String password1) {
        loginSteps.userLogin1(id1,password1);
    }

    @And("verify the first unsuccessful login scenario with {string}")
    public void verifyTheFirstUnsuccessfulLoginScenarioWith(String errorMessage) {
        loginSteps.verifyErrorMessageforFirstNegativeScenario(errorMessage);
    }

    @Then("Enter Invalid {string} and valid {string}")
    public void enterInvalidAndValid(String id2, String password2) {
        loginSteps.userLogin2(id2,password2);

    }
    @And("verify the second unsuccessful login scenario with {string}")
    public void verifyTheSecondUnsuccessfulLoginScenarioWith(String errorMessage) {
        loginSteps.verifyErrorMessageforSecondNegativeScenario(errorMessage);

    }

    @Then("Enter Invalid {string} and Invalid {string}")
    public void enterInvalidAndInvalid(String id3, String password3) {
            loginSteps.userLogin3(id3,password3);
    }
    @And("verify the third unsuccessful login scenario with {string}")
    public void verifyTheThirdUnsuccessfulLoginScenarioWith(String errorMessage) {
        loginSteps.verifyErrorMessageforThirdNegativeScenario(errorMessage);

    }


    @Then("Enter Valid {string} and Valid {string}")
    public void enterValidAndValid(String id, String password) {
        loginSteps.userLogin(id,password);
    }


    @And("Verify the successful login")
    public void verifyTheSuccessfulLogin() {
        loginSteps.verifyLogin();
    }


}
